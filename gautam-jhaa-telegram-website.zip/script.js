document.addEventListener("DOMContentLoaded", function () {
  const buttons = document.querySelectorAll('[data-subscribe-event="true"]');

  buttons.forEach(function (button) {
    button.addEventListener("click", function () {
      // Meta Pixel standard Subscribe event
      if (typeof window.fbq === "function") {
        window.fbq("track", "Subscribe", {
          content_name: "Gautam Jhaa Telegram Channel",
          content_category: "Telegram Community",
          status: true
        });
      }
    });
  });
});
